// assets/script.js
console.log("Campaign RTL script loaded.");
